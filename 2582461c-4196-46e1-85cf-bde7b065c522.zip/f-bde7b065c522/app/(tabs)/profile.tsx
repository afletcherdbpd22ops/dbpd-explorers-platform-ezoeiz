
import React, { useState } from "react";
import { View, Text, StyleSheet, ScrollView, Platform, Pressable, Alert, Modal, TextInput } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/IconSymbol";
import { GlassView } from "expo-glass-effect";
import { colors, commonStyles } from "@/styles/commonStyles";
import * as DocumentPicker from 'expo-document-picker';

interface ExplorerProfile {
  id: string;
  name: string;
  rank: string;
  badgeNumber: string;
  joinDate: string;
  communityServiceHours: number;
  trainingHours: number;
  commendations: number;
  specializations: string[];
  contact: {
    email: string;
    phone: string;
    emergencyContact: string;
  };
}

interface AttendanceRecord {
  id: string;
  eventType: 'meeting' | 'training' | 'patrol' | 'ceremony' | 'community-service';
  eventTitle: string;
  date: string;
  status: 'present' | 'absent' | 'excused' | 'late';
  duration: number; // in hours
  location: string;
  notes?: string;
}

interface CommunityServiceRecord {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  hours: number;
  type: 'food-bank' | 'school-visit' | 'charity-event' | 'cleanup' | 'safety-demo' | 'other';
  supervisor: string;
  verified: boolean;
  photos?: string[];
}

interface Document {
  id: string;
  title: string;
  type: 'certification' | 'award' | 'training-certificate' | 'commendation' | 'other';
  dateEarned: string;
  issuedBy: string;
  expirationDate?: string;
  fileUri?: string;
  description: string;
}

export default function ProfileScreen() {
  const [explorerProfile] = useState<ExplorerProfile>({
    id: '1',
    name: 'Alex Johnson',
    rank: 'Explorer Lieutenant',
    badgeNumber: 'EX-2024-015',
    joinDate: '2023-03-15',
    communityServiceHours: 127,
    trainingHours: 89,
    commendations: 3,
    specializations: ['Traffic Control', 'Community Outreach', 'Emergency Response'],
    contact: {
      email: 'alex.johnson@dbpoliceexplorers.org',
      phone: '(386) 555-0123',
      emergencyContact: '(386) 555-0456',
    },
  });

  const [attendanceRecords] = useState<AttendanceRecord[]>([
    {
      id: '1',
      eventType: 'meeting',
      eventTitle: 'Weekly Explorer Meeting',
      date: '2024-01-15',
      status: 'present',
      duration: 2,
      location: 'Police Station Conference Room',
      notes: 'Discussed upcoming community events'
    },
    {
      id: '2',
      eventType: 'training',
      eventTitle: 'Emergency Response Training',
      date: '2024-01-10',
      status: 'present',
      duration: 4,
      location: 'Training Facility',
      notes: 'CPR and First Aid certification'
    },
    {
      id: '3',
      eventType: 'community-service',
      eventTitle: 'Food Bank Volunteer',
      date: '2024-01-08',
      status: 'present',
      duration: 6,
      location: 'Daytona Beach Food Bank',
    },
    {
      id: '4',
      eventType: 'meeting',
      eventTitle: 'Monthly Leadership Meeting',
      date: '2024-01-05',
      status: 'late',
      duration: 1.5,
      location: 'Police Station Conference Room',
      notes: 'Arrived 15 minutes late due to traffic'
    },
    {
      id: '5',
      eventType: 'patrol',
      eventTitle: 'Downtown Patrol',
      date: '2024-01-03',
      status: 'present',
      duration: 8,
      location: 'Downtown Daytona Beach',
    },
  ]);

  const [communityServiceRecords] = useState<CommunityServiceRecord[]>([
    {
      id: '1',
      title: 'Food Bank Distribution',
      description: 'Assisted with sorting and distributing food packages to families in need',
      date: '2024-01-12',
      location: 'Daytona Beach Food Bank',
      hours: 4,
      type: 'food-bank',
      supervisor: 'Officer Martinez',
      verified: true,
    },
    {
      id: '2',
      title: 'School Safety Presentation',
      description: 'Presented safety tips and police procedures to elementary school students',
      date: '2024-01-05',
      location: 'Sunrise Elementary School',
      hours: 2,
      type: 'school-visit',
      supervisor: 'Officer Davis',
      verified: true,
    },
    {
      id: '3',
      title: 'Beach Cleanup Initiative',
      description: 'Organized and participated in community beach cleanup event',
      date: '2023-12-20',
      location: 'Daytona Beach Main Street Pier',
      hours: 6,
      type: 'cleanup',
      supervisor: 'Sergeant Thompson',
      verified: true,
    },
    {
      id: '4',
      title: 'Holiday Toy Drive',
      description: 'Collected and distributed toys for underprivileged children during holidays',
      date: '2023-12-15',
      location: 'Police Station',
      hours: 8,
      type: 'charity-event',
      supervisor: 'Officer Wilson',
      verified: true,
    },
  ]);

  const [documents] = useState<Document[]>([
    {
      id: '1',
      title: 'CPR Certification',
      type: 'certification',
      dateEarned: '2024-01-10',
      issuedBy: 'American Red Cross',
      expirationDate: '2026-01-10',
      description: 'Adult and Pediatric CPR/AED certification',
    },
    {
      id: '2',
      title: 'Community Service Excellence Award',
      type: 'award',
      dateEarned: '2023-12-01',
      issuedBy: 'Daytona Beach Police Department',
      description: 'Recognized for outstanding community service contributions',
    },
    {
      id: '3',
      title: 'Emergency Response Training Certificate',
      type: 'training-certificate',
      dateEarned: '2023-11-15',
      issuedBy: 'Florida Police Explorer Academy',
      description: 'Completed 40-hour emergency response training program',
    },
    {
      id: '4',
      title: 'Leadership Commendation',
      type: 'commendation',
      dateEarned: '2023-10-20',
      issuedBy: 'Explorer Advisor Council',
      description: 'Demonstrated exceptional leadership during community events',
    },
  ]);

  const [activeTab, setActiveTab] = useState<'overview' | 'attendance' | 'service' | 'documents'>('overview');
  const [showAddDocument, setShowAddDocument] = useState(false);
  const [newDocumentTitle, setNewDocumentTitle] = useState('');

  const getRankColor = (rank: string) => {
    switch (rank.toLowerCase()) {
      case 'advisor': return '#000080';
      case 'explorer major': return '#8B0000';
      case 'explorer captain': return '#FF4500';
      case 'explorer lieutenant': return colors.primary;
      case 'explorer sergeant': return '#32CD32';
      case 'explorer corporal': return '#FFD700';
      case 'explorer': return colors.secondary;
      default: return colors.textSecondary;
    }
  };

  const getAttendanceStatusColor = (status: AttendanceRecord['status']) => {
    switch (status) {
      case 'present': return colors.success;
      case 'late': return colors.warning;
      case 'excused': return colors.primary;
      case 'absent': return colors.error;
      default: return colors.textSecondary;
    }
  };

  const getAttendanceStatusIcon = (status: AttendanceRecord['status']) => {
    switch (status) {
      case 'present': return 'checkmark.circle.fill';
      case 'late': return 'clock.fill';
      case 'excused': return 'info.circle.fill';
      case 'absent': return 'xmark.circle.fill';
      default: return 'questionmark.circle.fill';
    }
  };

  const getEventTypeIcon = (type: AttendanceRecord['eventType']) => {
    switch (type) {
      case 'meeting': return 'person.3.fill';
      case 'training': return 'book.fill';
      case 'patrol': return 'car.fill';
      case 'ceremony': return 'star.fill';
      case 'community-service': return 'heart.fill';
      default: return 'calendar';
    }
  };

  const getCommunityServiceTypeIcon = (type: CommunityServiceRecord['type']) => {
    switch (type) {
      case 'food-bank': return 'basket.fill';
      case 'school-visit': return 'graduationcap.fill';
      case 'charity-event': return 'gift.fill';
      case 'cleanup': return 'leaf.fill';
      case 'safety-demo': return 'shield.fill';
      default: return 'heart.fill';
    }
  };

  const getDocumentTypeIcon = (type: Document['type']) => {
    switch (type) {
      case 'certification': return 'checkmark.seal.fill';
      case 'award': return 'trophy.fill';
      case 'training-certificate': return 'graduationcap.fill';
      case 'commendation': return 'star.fill';
      default: return 'doc.fill';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const formatDateLong = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const calculateAttendanceRate = () => {
    const totalEvents = attendanceRecords.length;
    const presentEvents = attendanceRecords.filter(record => 
      record.status === 'present' || record.status === 'late'
    ).length;
    return totalEvents > 0 ? Math.round((presentEvents / totalEvents) * 100) : 0;
  };

  const getTotalServiceHours = () => {
    return communityServiceRecords.reduce((total, record) => total + record.hours, 0);
  };

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        copyToCacheDirectory: true,
      });
      
      if (!result.canceled) {
        console.log('Document picked:', result.assets[0]);
        Alert.alert('Document Added', 'Document would be uploaded and stored in the system.');
        setShowAddDocument(false);
        setNewDocumentTitle('');
      }
    } catch (error) {
      console.error('Error picking document:', error);
      Alert.alert('Error', 'Failed to pick document');
    }
  };

  const renderTabButton = (tab: typeof activeTab, title: string, icon: string) => (
    <Pressable
      key={tab}
      onPress={() => setActiveTab(tab)}
      style={[
        styles.tabButton,
        activeTab === tab && { backgroundColor: colors.primary }
      ]}
    >
      <IconSymbol 
        name={icon as any} 
        color={activeTab === tab ? 'white' : colors.textSecondary} 
        size={16} 
      />
      <Text style={[
        styles.tabButtonText,
        { color: activeTab === tab ? 'white' : colors.textSecondary }
      ]}>
        {title}
      </Text>
    </Pressable>
  );

  const renderOverviewTab = () => (
    <>
      {/* Stats Cards */}
      <View style={styles.statsContainer}>
        <View style={[commonStyles.card, styles.statCard]}>
          <IconSymbol name="percent" color={colors.primary} size={32} />
          <Text style={[styles.statNumber, { color: colors.text }]}>
            {calculateAttendanceRate()}%
          </Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>
            Attendance Rate
          </Text>
        </View>
        <View style={[commonStyles.card, styles.statCard]}>
          <IconSymbol name="heart.fill" color={colors.success} size={32} />
          <Text style={[styles.statNumber, { color: colors.text }]}>
            {getTotalServiceHours()}
          </Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>
            Service Hours
          </Text>
        </View>
        <View style={[commonStyles.card, styles.statCard]}>
          <IconSymbol name="doc.fill" color={colors.accent} size={32} />
          <Text style={[styles.statNumber, { color: colors.text }]}>
            {documents.length}
          </Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>
            Documents
          </Text>
        </View>
      </View>

      {/* Profile Information */}
      <View style={[commonStyles.card, styles.infoSection]}>
        <Text style={[commonStyles.subtitle, { color: colors.text, marginBottom: 16 }]}>
          Profile Information
        </Text>
        <View style={styles.infoRow}>
          <IconSymbol name="calendar" color={colors.textSecondary} size={20} />
          <View style={styles.infoContent}>
            <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>Join Date</Text>
            <Text style={[styles.infoValue, { color: colors.text }]}>
              {formatDateLong(explorerProfile.joinDate)}
            </Text>
          </View>
        </View>
        <View style={styles.infoRow}>
          <IconSymbol name="envelope.fill" color={colors.textSecondary} size={20} />
          <View style={styles.infoContent}>
            <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>Email</Text>
            <Text style={[styles.infoValue, { color: colors.text }]}>
              {explorerProfile.contact.email}
            </Text>
          </View>
        </View>
        <View style={styles.infoRow}>
          <IconSymbol name="phone.fill" color={colors.textSecondary} size={20} />
          <View style={styles.infoContent}>
            <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>Phone</Text>
            <Text style={[styles.infoValue, { color: colors.text }]}>
              {explorerProfile.contact.phone}
            </Text>
          </View>
        </View>
      </View>

      {/* Specializations */}
      <View style={[commonStyles.card, styles.specializationsSection]}>
        <Text style={[commonStyles.subtitle, { color: colors.text, marginBottom: 16 }]}>
          Specializations
        </Text>
        <View style={styles.specializationsList}>
          {explorerProfile.specializations.map((specialization, index) => (
            <View key={index} style={[styles.specializationTag, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.specializationText, { color: colors.text }]}>
                {specialization}
              </Text>
            </View>
          ))}
        </View>
      </View>
    </>
  );

  const renderAttendanceTab = () => (
    <View style={[commonStyles.card, styles.attendanceSection]}>
      <View style={styles.sectionHeader}>
        <Text style={[commonStyles.subtitle, { color: colors.text }]}>
          Meeting Attendance Log
        </Text>
        <View style={styles.attendanceStats}>
          <Text style={[styles.attendanceRate, { color: colors.success }]}>
            {calculateAttendanceRate()}% Attendance Rate
          </Text>
        </View>
      </View>
      
      <View style={styles.attendanceList}>
        {attendanceRecords.map((record) => (
          <View key={record.id} style={styles.attendanceItem}>
            <View style={styles.attendanceHeader}>
              <View style={styles.attendanceInfo}>
                <View style={styles.attendanceTitleRow}>
                  <IconSymbol 
                    name={getEventTypeIcon(record.eventType) as any} 
                    color={colors.primary} 
                    size={16} 
                  />
                  <Text style={[styles.attendanceTitle, { color: colors.text }]}>
                    {record.eventTitle}
                  </Text>
                </View>
                <Text style={[styles.attendanceDate, { color: colors.textSecondary }]}>
                  {formatDate(record.date)} • {record.duration}h • {record.location}
                </Text>
                {record.notes && (
                  <Text style={[styles.attendanceNotes, { color: colors.textSecondary }]}>
                    {record.notes}
                  </Text>
                )}
              </View>
              <View style={[
                styles.attendanceStatus,
                { backgroundColor: getAttendanceStatusColor(record.status) }
              ]}>
                <IconSymbol 
                  name={getAttendanceStatusIcon(record.status) as any} 
                  color="white" 
                  size={16} 
                />
                <Text style={styles.attendanceStatusText}>
                  {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                </Text>
              </View>
            </View>
          </View>
        ))}
      </View>
    </View>
  );

  const renderServiceTab = () => (
    <View style={[commonStyles.card, styles.serviceSection]}>
      <View style={styles.sectionHeader}>
        <Text style={[commonStyles.subtitle, { color: colors.text }]}>
          Community Service Details
        </Text>
        <Text style={[styles.totalHours, { color: colors.success }]}>
          Total: {getTotalServiceHours()} hours
        </Text>
      </View>
      
      <View style={styles.serviceList}>
        {communityServiceRecords.map((record) => (
          <View key={record.id} style={styles.serviceItem}>
            <View style={styles.serviceHeader}>
              <View style={[
                styles.serviceTypeIcon,
                { backgroundColor: colors.primary }
              ]}>
                <IconSymbol 
                  name={getCommunityServiceTypeIcon(record.type) as any} 
                  color="white" 
                  size={20} 
                />
              </View>
              <View style={styles.serviceInfo}>
                <View style={styles.serviceTitleRow}>
                  <Text style={[styles.serviceTitle, { color: colors.text }]}>
                    {record.title}
                  </Text>
                  {record.verified && (
                    <IconSymbol name="checkmark.seal.fill" color={colors.success} size={16} />
                  )}
                </View>
                <Text style={[styles.serviceDescription, { color: colors.textSecondary }]}>
                  {record.description}
                </Text>
                <View style={styles.serviceDetails}>
                  <Text style={[styles.serviceDate, { color: colors.textSecondary }]}>
                    {formatDate(record.date)} • {record.hours}h
                  </Text>
                  <Text style={[styles.serviceLocation, { color: colors.textSecondary }]}>
                    📍 {record.location}
                  </Text>
                  <Text style={[styles.serviceSupervisor, { color: colors.textSecondary }]}>
                    Supervisor: {record.supervisor}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        ))}
      </View>
    </View>
  );

  const renderDocumentsTab = () => (
    <View style={[commonStyles.card, styles.documentsSection]}>
      <View style={styles.sectionHeader}>
        <Text style={[commonStyles.subtitle, { color: colors.text }]}>
          Certifications & Awards
        </Text>
        <Pressable 
          onPress={() => setShowAddDocument(true)}
          style={[styles.addButton, { backgroundColor: colors.primary }]}
        >
          <IconSymbol name="plus" color="white" size={16} />
        </Pressable>
      </View>
      
      <View style={styles.documentsList}>
        {documents.map((document) => (
          <View key={document.id} style={styles.documentItem}>
            <View style={[
              styles.documentIcon,
              { backgroundColor: colors.secondary }
            ]}>
              <IconSymbol 
                name={getDocumentTypeIcon(document.type) as any} 
                color={colors.primary} 
                size={24} 
              />
            </View>
            <View style={styles.documentInfo}>
              <Text style={[styles.documentTitle, { color: colors.text }]}>
                {document.title}
              </Text>
              <Text style={[styles.documentDescription, { color: colors.textSecondary }]}>
                {document.description}
              </Text>
              <View style={styles.documentDetails}>
                <Text style={[styles.documentDate, { color: colors.textSecondary }]}>
                  Earned: {formatDate(document.dateEarned)}
                </Text>
                <Text style={[styles.documentIssuer, { color: colors.textSecondary }]}>
                  Issued by: {document.issuedBy}
                </Text>
                {document.expirationDate && (
                  <Text style={[styles.documentExpiration, { color: colors.warning }]}>
                    Expires: {formatDate(document.expirationDate)}
                  </Text>
                )}
              </View>
            </View>
            <Pressable style={styles.documentAction}>
              <IconSymbol name="eye.fill" color={colors.primary} size={20} />
            </Pressable>
          </View>
        ))}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={[commonStyles.wrapper]} edges={['top']}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={[
          styles.contentContainer,
          Platform.OS !== 'ios' && styles.contentContainerWithTabBar
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Header */}
        <GlassView style={[
          styles.profileHeader,
          Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.9)' }
        ]} glassEffectStyle="regular">
          <View style={styles.profileImageContainer}>
            <IconSymbol name="person.circle.fill" size={80} color={colors.primary} />
            <View style={[styles.rankBadge, { backgroundColor: getRankColor(explorerProfile.rank) }]}>
              <Text style={styles.rankBadgeText}>
                {explorerProfile.rank === 'Advisor' ? 'ADV' : explorerProfile.rank.split(' ')[1] || 'EXP'}
              </Text>
            </View>
          </View>
          <Text style={[styles.profileName, { color: colors.text }]}>
            {explorerProfile.name}
          </Text>
          <Text style={[styles.profileRank, { color: getRankColor(explorerProfile.rank) }]}>
            {explorerProfile.rank}
          </Text>
          <Text style={[styles.badgeNumber, { color: colors.textSecondary }]}>
            Badge #{explorerProfile.badgeNumber}
          </Text>
        </GlassView>

        {/* Tab Navigation */}
        <View style={styles.tabContainer}>
          {renderTabButton('overview', 'Overview', 'person.fill')}
          {renderTabButton('attendance', 'Attendance', 'calendar')}
          {renderTabButton('service', 'Service', 'heart.fill')}
          {renderTabButton('documents', 'Documents', 'doc.fill')}
        </View>

        {/* Tab Content */}
        {activeTab === 'overview' && renderOverviewTab()}
        {activeTab === 'attendance' && renderAttendanceTab()}
        {activeTab === 'service' && renderServiceTab()}
        {activeTab === 'documents' && renderDocumentsTab()}

        {/* Add Document Modal */}
        <Modal
          visible={showAddDocument}
          transparent
          animationType="slide"
          onRequestClose={() => setShowAddDocument(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>
                Add Document
              </Text>
              <TextInput
                style={[styles.modalInput, { 
                  backgroundColor: colors.background,
                  color: colors.text,
                  borderColor: colors.border 
                }]}
                placeholder="Document title"
                placeholderTextColor={colors.textSecondary}
                value={newDocumentTitle}
                onChangeText={setNewDocumentTitle}
              />
              <View style={styles.modalButtons}>
                <Pressable
                  onPress={() => setShowAddDocument(false)}
                  style={[styles.modalButton, { backgroundColor: colors.textSecondary }]}
                >
                  <Text style={styles.modalButtonText}>Cancel</Text>
                </Pressable>
                <Pressable
                  onPress={pickDocument}
                  style={[styles.modalButton, { backgroundColor: colors.primary }]}
                >
                  <Text style={styles.modalButtonText}>Pick File</Text>
                </Pressable>
              </View>
            </View>
          </View>
        </Modal>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  contentContainerWithTabBar: {
    paddingBottom: 100,
  },
  profileHeader: {
    alignItems: 'center',
    borderRadius: 12,
    padding: 32,
    marginBottom: 24,
  },
  profileImageContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  rankBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.card,
  },
  rankBadgeText: {
    color: 'white',
    fontSize: 10,
    fontWeight: '700',
  },
  profileName: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 4,
  },
  profileRank: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  badgeNumber: {
    fontSize: 14,
    marginBottom: 16,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 4,
    marginBottom: 24,
  },
  tabButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 8,
    gap: 6,
  },
  tabButtonText: {
    fontSize: 12,
    fontWeight: '600',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
    gap: 12,
  },
  statCard: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 20,
  },
  statNumber: {
    fontSize: 28,
    fontWeight: '700',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    textAlign: 'center',
  },
  infoSection: {
    marginBottom: 24,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  infoContent: {
    marginLeft: 16,
    flex: 1,
  },
  infoLabel: {
    fontSize: 12,
    marginBottom: 2,
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '500',
  },
  specializationsSection: {
    marginBottom: 24,
  },
  specializationsList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  specializationTag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  specializationText: {
    fontSize: 12,
    fontWeight: '600',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  attendanceSection: {
    marginBottom: 24,
  },
  attendanceStats: {
    alignItems: 'flex-end',
  },
  attendanceRate: {
    fontSize: 14,
    fontWeight: '600',
  },
  attendanceList: {
    gap: 16,
  },
  attendanceItem: {
    borderLeftWidth: 4,
    borderLeftColor: colors.primary,
    paddingLeft: 16,
  },
  attendanceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  attendanceInfo: {
    flex: 1,
    marginRight: 12,
  },
  attendanceTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  attendanceTitle: {
    fontSize: 16,
    fontWeight: '600',
  },
  attendanceDate: {
    fontSize: 12,
    marginBottom: 4,
  },
  attendanceNotes: {
    fontSize: 12,
    fontStyle: 'italic',
  },
  attendanceStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  attendanceStatusText: {
    color: 'white',
    fontSize: 10,
    fontWeight: '600',
  },
  serviceSection: {
    marginBottom: 24,
  },
  totalHours: {
    fontSize: 14,
    fontWeight: '600',
  },
  serviceList: {
    gap: 20,
  },
  serviceItem: {
    borderRadius: 8,
    backgroundColor: colors.background,
    padding: 16,
  },
  serviceHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  serviceTypeIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceInfo: {
    flex: 1,
  },
  serviceTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  serviceTitle: {
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
  },
  serviceDescription: {
    fontSize: 14,
    lineHeight: 18,
    marginBottom: 8,
  },
  serviceDetails: {
    gap: 2,
  },
  serviceDate: {
    fontSize: 12,
  },
  serviceLocation: {
    fontSize: 12,
  },
  serviceSupervisor: {
    fontSize: 12,
  },
  documentsSection: {
    marginBottom: 24,
  },
  addButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  documentsList: {
    gap: 16,
  },
  documentItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    padding: 16,
    backgroundColor: colors.background,
    borderRadius: 8,
  },
  documentIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  documentInfo: {
    flex: 1,
  },
  documentTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  documentDescription: {
    fontSize: 14,
    lineHeight: 18,
    marginBottom: 8,
  },
  documentDetails: {
    gap: 2,
  },
  documentDate: {
    fontSize: 12,
  },
  documentIssuer: {
    fontSize: 12,
  },
  documentExpiration: {
    fontSize: 12,
    fontWeight: '500',
  },
  documentAction: {
    padding: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    maxWidth: 400,
    borderRadius: 12,
    padding: 24,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
    textAlign: 'center',
  },
  modalInput: {
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 20,
    fontSize: 16,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});
